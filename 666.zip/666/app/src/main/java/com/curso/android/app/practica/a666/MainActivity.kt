package com.curso.android.app.practica.a666

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val editText1 = findViewById<EditText>(R.id.editText1)
        val editText2 = findViewById<EditText>(R.id.editText2)
        val button = findViewById<Button>(R.id.button)
        val textView = findViewById<TextView>(R.id.textView)

        button.setOnClickListener {
            val text1 = editText1.text.toString()
            val text2 = editText2.text.toString()
            if (text1 == text2) {
                textView.text = "Los textos son iguales"
            } else {
                textView.text = "Los textos son diferentes"
            }
        }
    }
}
